# 宝塔面板部署指南

## 准备工作

### 1. 打包文件

在本地 Windows 电脑上：

```bash
cd E:\Hanabi-Download-Manager-X-main\web_stats
deploy_local.bat
```

这会创建一个 `hanabi-stats-YYYYMMDD_HHMMSS.zip` 文件。

## 部署步骤

### 第一步：上传文件

1. 登录宝塔面板
2. 点击 **文件** 菜单
3. 创建目录：
   - `/opt/hanabi-stats` (服务器端)
   - `/var/www/hanabi-stats` (网页端)
4. 上传 `hanabi-stats-*.zip` 到服务器
5. 解压文件：
   - 将 `server.js` 复制到 `/opt/hanabi-stats/`
   - 将其他文件复制到 `/var/www/hanabi-stats/`

### 第二步：安装 Node.js

1. 点击 **软件商店**
2. 搜索 "Node.js"
3. 安装 **Node.js 版本管理器** 或 **Node.js 18.x**
4. 等待安装完成

### 第三步：安装 PM2

1. 点击 **终端**
2. 运行命令：

```bash
npm install -g pm2
```

### 第四步：启动服务

在终端中运行：

```bash
cd /opt/hanabi-stats
pm2 start server.js --name hanabi-stats
pm2 save
pm2 startup
```

验证服务运行：

```bash
pm2 status
pm2 logs hanabi-stats
curl http://localhost:3000/health
```

### 第五步：配置网站

1. 点击 **网站** 菜单
2. 点击 **添加站点**
3. 填写信息：
   - **域名**: `online.zzbuaoye.top`
   - **根目录**: `/var/www/hanabi-stats`
   - **PHP版本**: 纯静态
   - **数据库**: 不创建
   - **FTP**: 不创建
4. 点击 **提交**

### 第六步：配置反向代理

1. 找到刚创建的网站，点击 **设置**
2. 点击 **反向代理** 标签
3. 点击 **添加反向代理**
4. 填写信息：

**配置 1: API 接口**
```
代理名称: hanabi-api
目标URL: http://127.0.0.1:3000
发送域名: $host
```

在 **配置文件** 中添加：

```nginx
# API endpoints
location /api/ {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}

# Health check
location /health {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
}
```

5. 保存配置

### 第七步：申请 SSL 证书

1. 在网站设置中，点击 **SSL** 标签
2. 选择 **Let's Encrypt**
3. 勾选域名 `online.zzbuaoye.top`
4. 点击 **申请**
5. 等待证书申请完成
6. 开启 **强制HTTPS**

### 第八步：测试

1. 访问 `https://online.zzbuaoye.top`
2. 应该看到统计页面
3. 测试 API：`https://online.zzbuaoye.top/health`

## 完整的 Nginx 配置示例

如果需要手动配置，完整的 Nginx 配置如下：

```nginx
server {
    listen 80;
    listen 443 ssl http2;
    server_name online.zzbuaoye.top;
    
    # SSL 证书（宝塔自动配置）
    ssl_certificate /www/server/panel/vhost/cert/online.zzbuaoye.top/fullchain.pem;
    ssl_certificate_key /www/server/panel/vhost/cert/online.zzbuaoye.top/privkey.pem;
    
    # SSL 配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # 强制 HTTPS
    if ($server_port !~ 443){
        rewrite ^(/.*)$ https://$host$1 permanent;
    }
    
    # API endpoints
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Health check
    location /health {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
    }
    
    # Web dashboard
    location / {
        root /var/www/hanabi-stats;
        index index.html;
        try_files $uri $uri/ /index.html;
    }
    
    # 访问日志
    access_log /www/wwwlogs/online.zzbuaoye.top.log;
    error_log /www/wwwlogs/online.zzbuaoye.top.error.log;
}
```

## 管理命令

### PM2 管理

```bash
# 查看状态
pm2 status

# 查看日志
pm2 logs hanabi-stats

# 重启服务
pm2 restart hanabi-stats

# 停止服务
pm2 stop hanabi-stats

# 删除服务
pm2 delete hanabi-stats
```

### 测试命令

```bash
# 测试服务器
curl http://localhost:3000/health

# 测试 API
curl http://localhost:3000/api/stats

# 测试网页
curl http://localhost/

# 测试 HTTPS
curl https://online.zzbuaoye.top/health
```

## 故障排除

### 问题 1: PM2 启动失败

```bash
# 检查 Node.js 版本
node --version

# 检查 PM2 版本
pm2 --version

# 查看详细错误
pm2 logs hanabi-stats --lines 100
```

### 问题 2: 网站无法访问

1. 检查防火墙：宝塔面板 -> 安全 -> 放行端口 80, 443
2. 检查 Nginx 配置：`nginx -t`
3. 重启 Nginx：宝塔面板 -> 软件商店 -> Nginx -> 重启

### 问题 3: API 无法访问

1. 检查 PM2 状态：`pm2 status`
2. 检查端口占用：`netstat -tlnp | grep 3000`
3. 查看服务器日志：`pm2 logs hanabi-stats`

### 问题 4: SSL 证书申请失败

1. 确保域名已解析到服务器 IP
2. 确保 80 端口可访问
3. 检查域名是否已被其他网站使用

## 更新部署

更新时只需：

1. 上传新的文件
2. 替换旧文件
3. 重启 PM2：`pm2 restart hanabi-stats`
4. 刷新浏览器缓存

## 备份

建议定期备份：

1. `/opt/hanabi-stats/` - 服务器代码
2. `/var/www/hanabi-stats/` - 网页文件
3. PM2 配置：`pm2 save`

## 监控

在宝塔面板中：

1. **监控** -> 查看服务器资源使用
2. **日志** -> 查看访问日志和错误日志
3. **PM2** -> 查看进程状态

## 完成

部署完成后：

1. ✅ 服务器运行在 `http://localhost:3000`
2. ✅ 网站可访问 `https://online.zzbuaoye.top`
3. ✅ API 可访问 `https://online.zzbuaoye.top/api/stats`
4. ✅ Flutter 客户端可以发送心跳
5. ✅ 网页端可以查看统计数据

访问 `https://online.zzbuaoye.top` 查看在线统计！
